package com.msw.mydemo14;

//
//	Data.java
//
//	Create by 莫 锹文 on 2017/12/14
//	Copyright © 2017. All rights reserved.


public class Data {

    private int active;
    private String bindTime;
    private int id;
    private int isDefault;
    private Object userAccount;
    private int userId;
    private String watchId;
    private String watchSim;
    private String watchType;

    public int getActive() {
        return this.active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public String getBindTime() {
        return this.bindTime;
    }

    public void setBindTime(String bindTime) {
        this.bindTime = bindTime;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIsDefault() {
        return this.isDefault;
    }

    public void setIsDefault(int isDefault) {
        this.isDefault = isDefault;
    }

    public Object getUserAccount() {
        return this.userAccount;
    }

    public void setUserAccount(Object userAccount) {
        this.userAccount = userAccount;
    }

    public int getUserId() {
        return this.userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getWatchId() {
        return this.watchId;
    }

    public void setWatchId(String watchId) {
        this.watchId = watchId;
    }

    public String getWatchSim() {
        return this.watchSim;
    }

    public void setWatchSim(String watchSim) {
        this.watchSim = watchSim;
    }

    public String getWatchType() {
        return this.watchType;
    }

    public void setWatchType(String watchType) {
        this.watchType = watchType;
    }

}